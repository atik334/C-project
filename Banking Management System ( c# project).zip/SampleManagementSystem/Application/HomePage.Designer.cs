﻿namespace App
{
    partial class HomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ManageEmpBtn = new System.Windows.Forms.Button();
            this.ManageProductBtn = new System.Windows.Forms.Button();
            this.ManageSalesBtn = new System.Windows.Forms.Button();
            this.ViewReportBtn = new System.Windows.Forms.Button();
            this.LogoutBtn = new System.Windows.Forms.Button();
            this.ChangePassBtn = new System.Windows.Forms.Button();
            this.WelcomeLabel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ManageEmpBtn
            // 
            this.ManageEmpBtn.BackColor = System.Drawing.Color.Yellow;
            this.ManageEmpBtn.Location = new System.Drawing.Point(42, 94);
            this.ManageEmpBtn.Name = "ManageEmpBtn";
            this.ManageEmpBtn.Size = new System.Drawing.Size(128, 65);
            this.ManageEmpBtn.TabIndex = 0;
            this.ManageEmpBtn.Text = "ManageEmployee";
            this.ManageEmpBtn.UseVisualStyleBackColor = false;
            this.ManageEmpBtn.Click += new System.EventHandler(this.ManageEmpBtn_Click);
            // 
            // ManageProductBtn
            // 
            this.ManageProductBtn.BackColor = System.Drawing.Color.Yellow;
            this.ManageProductBtn.Location = new System.Drawing.Point(187, 94);
            this.ManageProductBtn.Name = "ManageProductBtn";
            this.ManageProductBtn.Size = new System.Drawing.Size(118, 65);
            this.ManageProductBtn.TabIndex = 1;
            this.ManageProductBtn.Text = "Manage Product";
            this.ManageProductBtn.UseVisualStyleBackColor = false;
            // 
            // ManageSalesBtn
            // 
            this.ManageSalesBtn.BackColor = System.Drawing.Color.Yellow;
            this.ManageSalesBtn.Location = new System.Drawing.Point(334, 94);
            this.ManageSalesBtn.Name = "ManageSalesBtn";
            this.ManageSalesBtn.Size = new System.Drawing.Size(129, 65);
            this.ManageSalesBtn.TabIndex = 2;
            this.ManageSalesBtn.Text = "Manage Sales";
            this.ManageSalesBtn.UseVisualStyleBackColor = false;
            // 
            // ViewReportBtn
            // 
            this.ViewReportBtn.BackColor = System.Drawing.Color.Yellow;
            this.ViewReportBtn.Location = new System.Drawing.Point(484, 94);
            this.ViewReportBtn.Name = "ViewReportBtn";
            this.ViewReportBtn.Size = new System.Drawing.Size(118, 65);
            this.ViewReportBtn.TabIndex = 3;
            this.ViewReportBtn.Text = "View Report";
            this.ViewReportBtn.UseVisualStyleBackColor = false;
            // 
            // LogoutBtn
            // 
            this.LogoutBtn.Location = new System.Drawing.Point(692, 26);
            this.LogoutBtn.Name = "LogoutBtn";
            this.LogoutBtn.Size = new System.Drawing.Size(126, 29);
            this.LogoutBtn.TabIndex = 4;
            this.LogoutBtn.Text = "Logout";
            this.LogoutBtn.UseVisualStyleBackColor = true;
            this.LogoutBtn.Click += new System.EventHandler(this.LogoutBtn_Click);
            // 
            // ChangePassBtn
            // 
            this.ChangePassBtn.BackColor = System.Drawing.Color.Yellow;
            this.ChangePassBtn.Location = new System.Drawing.Point(634, 94);
            this.ChangePassBtn.Name = "ChangePassBtn";
            this.ChangePassBtn.Size = new System.Drawing.Size(118, 65);
            this.ChangePassBtn.TabIndex = 5;
            this.ChangePassBtn.Text = "Change Password";
            this.ChangePassBtn.UseVisualStyleBackColor = false;
            // 
            // WelcomeLabel
            // 
            this.WelcomeLabel.AutoSize = true;
            this.WelcomeLabel.Location = new System.Drawing.Point(215, 41);
            this.WelcomeLabel.Name = "WelcomeLabel";
            this.WelcomeLabel.Size = new System.Drawing.Size(52, 13);
            this.WelcomeLabel.TabIndex = 6;
            this.WelcomeLabel.Text = "Welcome";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Yellow;
            this.button1.Location = new System.Drawing.Point(42, 228);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(128, 65);
            this.button1.TabIndex = 7;
            this.button1.Text = "CustomerEmployee";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // HomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aqua;
            this.ClientSize = new System.Drawing.Size(940, 387);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.WelcomeLabel);
            this.Controls.Add(this.ChangePassBtn);
            this.Controls.Add(this.LogoutBtn);
            this.Controls.Add(this.ViewReportBtn);
            this.Controls.Add(this.ManageSalesBtn);
            this.Controls.Add(this.ManageProductBtn);
            this.Controls.Add(this.ManageEmpBtn);
            this.Name = "HomePage";
            this.Text = "HomePage";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.OnFormClose);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ManageEmpBtn;
        private System.Windows.Forms.Button ManageProductBtn;
        private System.Windows.Forms.Button ManageSalesBtn;
        private System.Windows.Forms.Button ViewReportBtn;
        private System.Windows.Forms.Button LogoutBtn;
        private System.Windows.Forms.Button ChangePassBtn;
        private System.Windows.Forms.Label WelcomeLabel;
        private System.Windows.Forms.Button button1;
    }
}