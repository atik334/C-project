﻿namespace App
{
    partial class ManageCustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RefreshBtnn = new System.Windows.Forms.Button();
            this.LogoutBtn = new System.Windows.Forms.Button();
            this.BackBtn = new System.Windows.Forms.Button();
            this.SearchLabel = new System.Windows.Forms.Label();
            this.SearchBoxx = new System.Windows.Forms.TextBox();
            this.ViewAllBtnn = new System.Windows.Forms.Button();
            this.DeleteBtnn = new System.Windows.Forms.Button();
            this.UpdateBtnn = new System.Windows.Forms.Button();
            this.InsertBtnn = new System.Windows.Forms.Button();
            this.LoadBtnn = new System.Windows.Forms.Button();
            this.CustTable = new System.Windows.Forms.DataGridView();
            this.CustPhnNumberTB2 = new System.Windows.Forms.TextBox();
            this.CustPhnNumberTB1 = new System.Windows.Forms.TextBox();
            this.CustNameTB = new System.Windows.Forms.TextBox();
            this.CustIdTF = new System.Windows.Forms.TextBox();
            this.EmpPhnNumberLabel = new System.Windows.Forms.Label();
            this.EmpNameLabel = new System.Windows.Forms.Label();
            this.EmpIdLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.CustTable)).BeginInit();
            this.SuspendLayout();
            // 
            // RefreshBtnn
            // 
            this.RefreshBtnn.Enabled = false;
            this.RefreshBtnn.Location = new System.Drawing.Point(47, 86);
            this.RefreshBtnn.Name = "RefreshBtnn";
            this.RefreshBtnn.Size = new System.Drawing.Size(324, 23);
            this.RefreshBtnn.TabIndex = 43;
            this.RefreshBtnn.Text = "Refresh Data";
            this.RefreshBtnn.UseVisualStyleBackColor = true;
            this.RefreshBtnn.Click += new System.EventHandler(this.RefreshBtnn_Click_1);
            // 
            // LogoutBtn
            // 
            this.LogoutBtn.Location = new System.Drawing.Point(746, 12);
            this.LogoutBtn.Name = "LogoutBtn";
            this.LogoutBtn.Size = new System.Drawing.Size(75, 23);
            this.LogoutBtn.TabIndex = 42;
            this.LogoutBtn.Text = "Logout";
            this.LogoutBtn.UseVisualStyleBackColor = true;
            this.LogoutBtn.Click += new System.EventHandler(this.LogoutBtn_Click);
            // 
            // BackBtn
            // 
            this.BackBtn.Location = new System.Drawing.Point(12, 12);
            this.BackBtn.Name = "BackBtn";
            this.BackBtn.Size = new System.Drawing.Size(75, 23);
            this.BackBtn.TabIndex = 41;
            this.BackBtn.Text = "Back";
            this.BackBtn.UseVisualStyleBackColor = true;
            this.BackBtn.Click += new System.EventHandler(this.BackBtn_Click);
            // 
            // SearchLabel
            // 
            this.SearchLabel.AutoSize = true;
            this.SearchLabel.Location = new System.Drawing.Point(383, 348);
            this.SearchLabel.Name = "SearchLabel";
            this.SearchLabel.Size = new System.Drawing.Size(76, 13);
            this.SearchLabel.TabIndex = 40;
            this.SearchLabel.Text = "Search Here : ";
            // 
            // SearchBoxx
            // 
            this.SearchBoxx.Location = new System.Drawing.Point(465, 345);
            this.SearchBoxx.Name = "SearchBoxx";
            this.SearchBoxx.Size = new System.Drawing.Size(340, 20);
            this.SearchBoxx.TabIndex = 39;
            this.SearchBoxx.TextChanged += new System.EventHandler(this.SearchBoxx_TextChanged);
            // 
            // ViewAllBtnn
            // 
            this.ViewAllBtnn.Location = new System.Drawing.Point(386, 86);
            this.ViewAllBtnn.Name = "ViewAllBtnn";
            this.ViewAllBtnn.Size = new System.Drawing.Size(419, 23);
            this.ViewAllBtnn.TabIndex = 38;
            this.ViewAllBtnn.Text = "View All Employee";
            this.ViewAllBtnn.UseVisualStyleBackColor = true;
            this.ViewAllBtnn.Click += new System.EventHandler(this.ViewAllBtnn_Click_1);
            // 
            // DeleteBtnn
            // 
            this.DeleteBtnn.Enabled = false;
            this.DeleteBtnn.Location = new System.Drawing.Point(296, 305);
            this.DeleteBtnn.Name = "DeleteBtnn";
            this.DeleteBtnn.Size = new System.Drawing.Size(75, 23);
            this.DeleteBtnn.TabIndex = 37;
            this.DeleteBtnn.Text = "Delete";
            this.DeleteBtnn.UseVisualStyleBackColor = true;
            this.DeleteBtnn.Click += new System.EventHandler(this.DeleteBtnn_Click_1);
            // 
            // UpdateBtnn
            // 
            this.UpdateBtnn.Enabled = false;
            this.UpdateBtnn.Location = new System.Drawing.Point(209, 305);
            this.UpdateBtnn.Name = "UpdateBtnn";
            this.UpdateBtnn.Size = new System.Drawing.Size(75, 23);
            this.UpdateBtnn.TabIndex = 36;
            this.UpdateBtnn.Text = "Update";
            this.UpdateBtnn.UseVisualStyleBackColor = true;
            this.UpdateBtnn.Click += new System.EventHandler(this.UpdateBtnn_Click_1);
            // 
            // InsertBtnn
            // 
            this.InsertBtnn.Location = new System.Drawing.Point(128, 305);
            this.InsertBtnn.Name = "InsertBtnn";
            this.InsertBtnn.Size = new System.Drawing.Size(75, 23);
            this.InsertBtnn.TabIndex = 35;
            this.InsertBtnn.Text = "Insert";
            this.InsertBtnn.UseVisualStyleBackColor = true;
            this.InsertBtnn.Click += new System.EventHandler(this.InsertBtnn_Click_1);
            // 
            // LoadBtnn
            // 
            this.LoadBtnn.Location = new System.Drawing.Point(47, 305);
            this.LoadBtnn.Name = "LoadBtnn";
            this.LoadBtnn.Size = new System.Drawing.Size(75, 23);
            this.LoadBtnn.TabIndex = 34;
            this.LoadBtnn.Text = "Load";
            this.LoadBtnn.UseVisualStyleBackColor = true;
            this.LoadBtnn.Click += new System.EventHandler(this.LoadBtnn_Click_1);
            // 
            // CustTable
            // 
            this.CustTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CustTable.Location = new System.Drawing.Point(386, 127);
            this.CustTable.Name = "CustTable";
            this.CustTable.ReadOnly = true;
            this.CustTable.Size = new System.Drawing.Size(419, 201);
            this.CustTable.TabIndex = 33;
            this.CustTable.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.CustTable_CellContentClick);
            // 
            // CustPhnNumberTB2
            // 
            this.CustPhnNumberTB2.Location = new System.Drawing.Point(243, 235);
            this.CustPhnNumberTB2.Name = "CustPhnNumberTB2";
            this.CustPhnNumberTB2.Size = new System.Drawing.Size(105, 20);
            this.CustPhnNumberTB2.TabIndex = 32;
            // 
            // CustPhnNumberTB1
            // 
            this.CustPhnNumberTB1.Enabled = false;
            this.CustPhnNumberTB1.Location = new System.Drawing.Point(202, 235);
            this.CustPhnNumberTB1.Name = "CustPhnNumberTB1";
            this.CustPhnNumberTB1.Size = new System.Drawing.Size(35, 20);
            this.CustPhnNumberTB1.TabIndex = 29;
            this.CustPhnNumberTB1.Text = "+880";
            // 
            // CustNameTB
            // 
            this.CustNameTB.Location = new System.Drawing.Point(202, 194);
            this.CustNameTB.Name = "CustNameTB";
            this.CustNameTB.Size = new System.Drawing.Size(146, 20);
            this.CustNameTB.TabIndex = 28;
            // 
            // CustIdTF
            // 
            this.CustIdTF.Location = new System.Drawing.Point(202, 152);
            this.CustIdTF.Name = "CustIdTF";
            this.CustIdTF.Size = new System.Drawing.Size(146, 20);
            this.CustIdTF.TabIndex = 27;
            // 
            // EmpPhnNumberLabel
            // 
            this.EmpPhnNumberLabel.AutoSize = true;
            this.EmpPhnNumberLabel.Location = new System.Drawing.Point(44, 238);
            this.EmpPhnNumberLabel.Name = "EmpPhnNumberLabel";
            this.EmpPhnNumberLabel.Size = new System.Drawing.Size(122, 13);
            this.EmpPhnNumberLabel.TabIndex = 24;
            this.EmpPhnNumberLabel.Text = "Customer Phn Number : ";
            // 
            // EmpNameLabel
            // 
            this.EmpNameLabel.AutoSize = true;
            this.EmpNameLabel.Location = new System.Drawing.Point(75, 194);
            this.EmpNameLabel.Name = "EmpNameLabel";
            this.EmpNameLabel.Size = new System.Drawing.Size(91, 13);
            this.EmpNameLabel.TabIndex = 23;
            this.EmpNameLabel.Text = "Customer Name : ";
            // 
            // EmpIdLabel
            // 
            this.EmpIdLabel.AutoSize = true;
            this.EmpIdLabel.Location = new System.Drawing.Point(92, 152);
            this.EmpIdLabel.Name = "EmpIdLabel";
            this.EmpIdLabel.Size = new System.Drawing.Size(74, 13);
            this.EmpIdLabel.TabIndex = 22;
            this.EmpIdLabel.Text = "Customer ID : ";
            // 
            // ManageCustomerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aqua;
            this.ClientSize = new System.Drawing.Size(914, 411);
            this.Controls.Add(this.RefreshBtnn);
            this.Controls.Add(this.LogoutBtn);
            this.Controls.Add(this.BackBtn);
            this.Controls.Add(this.SearchLabel);
            this.Controls.Add(this.SearchBoxx);
            this.Controls.Add(this.ViewAllBtnn);
            this.Controls.Add(this.DeleteBtnn);
            this.Controls.Add(this.UpdateBtnn);
            this.Controls.Add(this.InsertBtnn);
            this.Controls.Add(this.LoadBtnn);
            this.Controls.Add(this.CustTable);
            this.Controls.Add(this.CustPhnNumberTB2);
            this.Controls.Add(this.CustPhnNumberTB1);
            this.Controls.Add(this.CustNameTB);
            this.Controls.Add(this.CustIdTF);
            this.Controls.Add(this.EmpPhnNumberLabel);
            this.Controls.Add(this.EmpNameLabel);
            this.Controls.Add(this.EmpIdLabel);
            this.Name = "ManageCustomerForm";
            this.Text = "ManageCustomerForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.OnFormClose);
            ((System.ComponentModel.ISupportInitialize)(this.CustTable)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button RefreshBtnn;
        private System.Windows.Forms.Button LogoutBtn;
        private System.Windows.Forms.Button BackBtn;
        private System.Windows.Forms.Label SearchLabel;
        private System.Windows.Forms.TextBox SearchBoxx;
        private System.Windows.Forms.Button ViewAllBtnn;
        private System.Windows.Forms.Button DeleteBtnn;
        private System.Windows.Forms.Button UpdateBtnn;
        private System.Windows.Forms.Button InsertBtnn;
        private System.Windows.Forms.Button LoadBtnn;
        private System.Windows.Forms.DataGridView CustTable;
        private System.Windows.Forms.TextBox CustPhnNumberTB2;
        private System.Windows.Forms.TextBox CustPhnNumberTB1;
        private System.Windows.Forms.TextBox CustNameTB;
        private System.Windows.Forms.TextBox CustIdTF;
        private System.Windows.Forms.Label EmpPhnNumberLabel;
        private System.Windows.Forms.Label EmpNameLabel;
        private System.Windows.Forms.Label EmpIdLabel;
    }
}